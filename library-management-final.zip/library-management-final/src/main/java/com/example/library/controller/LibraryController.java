package com.example.library.controller;
import com.example.library.entity.Book;
import com.example.library.entity.Borrow;
import com.example.library.repository.BookRepository;
import com.example.library.repository.BorrowRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Optional;

@Controller
public class LibraryController {
    private final BookRepository bookRepo;
    private final BorrowRepository borrowRepo;

    public LibraryController(BookRepository bookRepo, BorrowRepository borrowRepo) {
        this.bookRepo = bookRepo;
        this.borrowRepo = borrowRepo;
    }

    @GetMapping("/")
    public String viewBooks(Model model) {
        model.addAttribute("books", bookRepo.findAll());
        return "books";
    }

    @PostMapping("/borrow/{bookId}")
    public String borrowBook(@PathVariable Long bookId) {
        Optional<Book> bookOpt = bookRepo.findById(bookId);
        if (bookOpt.isPresent()) {
            Book book = bookOpt.get();
            if (book.isAvailable()) {
                book.setAvailable(false);
                bookRepo.save(book);

                Borrow borrow = new Borrow();
                borrow.setBook(book);
                borrow.setUserId(1L);
                borrow.setBorrowDate(LocalDate.now());
                borrowRepo.save(borrow);
            }
        }
        return "redirect:/";
    }
}