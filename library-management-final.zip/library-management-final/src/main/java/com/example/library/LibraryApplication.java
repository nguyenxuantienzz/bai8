package com.example.library;

import com.example.library.entity.Book;
import com.example.library.repository.BookRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class LibraryApplication {
    public static void main(String[] args) {
        SpringApplication.run(LibraryApplication.class, args);
    }

    @Bean
    public CommandLineRunner dataLoader(BookRepository bookRepository) {
        return args -> {
            Book book1 = new Book();
            book1.setTitle("Sách Java");
            book1.setAuthor("Cao Duy Dương");
            book1.setAvailable(true);

            Book book2 = new Book();
            book2.setTitle("Sách Python");
            book2.setAuthor("Nguyễn Thành Công");
            book2.setAvailable(true);

            bookRepository.save(book1);
            bookRepository.save(book2);
        };
    }
}
